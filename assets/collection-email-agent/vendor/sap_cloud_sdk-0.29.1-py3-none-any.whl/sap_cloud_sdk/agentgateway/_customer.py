"""Customer agent flow - file-based credentials with mTLS authentication.

Customer agents read credentials from a file mounted on the pod filesystem.
This flow is used when credential files are detected.

Authentication flow:
- Tool discovery: mTLS client credentials → system-scoped token
- Tool invocation: mTLS + jwt-bearer grant → user-scoped token (principal propagation)
"""

import json
import logging
import os
import ssl
import tempfile
import uuid

import httpx
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client

from sap_cloud_sdk.agentgateway._models import (
    CustomerCredentials,
    IntegrationDependency,
    MCPTool,
)
from sap_cloud_sdk.agentgateway._token_cache import _TokenCache
from sap_cloud_sdk.agentgateway.exceptions import AgentGatewaySDKError

logger = logging.getLogger(__name__)

# Environment variable to override default credential path (points directly to credentials file)
_CREDENTIALS_PATH_ENV = "AGW_CREDENTIALS_PATH"

# servicebinding.io: scan $SERVICE_BINDING_ROOT for a binding whose 'type' file equals the expected type
_SERVICE_BINDING_ROOT_ENV = "SERVICE_BINDING_ROOT"
_BINDING_TYPE = "integration-credentials"
_BINDING_TYPE_FILE = "type"
_CREDENTIALS_FILE = "credentials"

# Kyma default when SERVICE_BINDING_ROOT is not set
_DEFAULT_BINDING_ROOT = "/bindings"

# Resource URN for Agent Gateway token scope (hardcoded - production value)
_AGW_RESOURCE_URN = "urn:sap:identity:application:provider:name:agent-gateway"

# OAuth2 grant types
_GRANT_TYPE_CLIENT_CREDENTIALS = "client_credentials"
_GRANT_TYPE_JWT_BEARER = "urn:ietf:params:oauth:grant-type:jwt-bearer"


def _cache_scope_key(credentials: CustomerCredentials, app_tid: str | None) -> str:
    """Build a cache scope key for customer-flow tokens."""
    return f"customer::{credentials.client_id}::{app_tid or ''}"


class _CredentialFields:
    """Field names in the credentials JSON file."""

    TOKEN_SERVICE_URL = "tokenServiceUrl"
    CLIENT_ID = "clientid"
    CERTIFICATE = "certificate"
    PRIVATE_KEY = "privateKey"
    GATEWAY_URL = "gatewayUrl"
    INTEGRATION_DEPENDENCIES = "integrationDependencies"
    ORD_ID = "ordId"
    DATA = "data"
    GLOBAL_TENANT_ID = "globalTenantId"


def detect_customer_agent_credentials() -> str | None:
    """Check if customer agent credentials file exists.

    Checks for credential file in the following order:
    1. Path specified in AGW_CREDENTIALS_PATH env var (explicit override, points to file directly)
    2. $SERVICE_BINDING_ROOT (or /bindings if unset): scans all subdirectories for one whose
       'type' file contains 'integration-credentials', then reads 'credentials' from that directory

    Returns:
        Path to credentials file if found, None otherwise.
    """
    # 1. Explicit override via env var
    path_from_env = os.environ.get(_CREDENTIALS_PATH_ENV)
    if path_from_env and os.path.isfile(path_from_env):
        logger.debug("Customer credentials found at env var path: %s", path_from_env)
        return path_from_env

    # 2. servicebinding.io: scan $SERVICE_BINDING_ROOT for a binding whose 'type' file equals _BINDING_TYPE
    sbr = os.environ.get(_SERVICE_BINDING_ROOT_ENV, _DEFAULT_BINDING_ROOT)
    if sbr and os.path.isdir(sbr):
        for entry in os.scandir(sbr):
            if not entry.is_dir():
                continue
            type_file = os.path.join(entry.path, _BINDING_TYPE_FILE)
            if not os.path.isfile(type_file):
                continue
            with open(type_file) as f:
                if f.read().strip() != _BINDING_TYPE:
                    continue
            credentials_path = os.path.join(entry.path, _CREDENTIALS_FILE)
            if os.path.isfile(credentials_path):
                logger.debug("Customer credentials found via servicebinding.io type scan: %s", credentials_path)
                return credentials_path

    return None


def load_customer_credentials(path: str) -> CustomerCredentials:
    """Load and parse customer credentials from file.

    Args:
        path: Path to the credentials JSON file.

    Returns:
        Parsed CustomerCredentials.

    Raises:
        AgentGatewaySDKError: If file cannot be read or is missing required fields.
    """
    logger.debug("Loading customer credentials from: %s", path)

    try:
        with open(path, "r") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        raise AgentGatewaySDKError(f"Failed to load credentials from '{path}': {e}")

    # Map credential file keys to dataclass fields
    # Credential file uses camelCase, we use snake_case
    required_fields = {
        _CredentialFields.TOKEN_SERVICE_URL: "token_service_url",
        _CredentialFields.CLIENT_ID: "client_id",
        _CredentialFields.CERTIFICATE: "certificate",
        _CredentialFields.PRIVATE_KEY: "private_key",
        _CredentialFields.GATEWAY_URL: "gateway_url",
    }

    missing = [k for k in required_fields if k not in data]
    if missing:
        raise AgentGatewaySDKError(
            f"Credentials file missing required fields: {missing}"
        )

    # Parse integrationDependencies (required)
    if _CredentialFields.INTEGRATION_DEPENDENCIES not in data:
        raise AgentGatewaySDKError(
            "Credentials file missing required field: integrationDependencies. "
            'Expected format: [{"ordId": "...", "globalTenantId": "..."}]'
        )

    try:
        integration_deps = [
            IntegrationDependency(
                ord_id=dep[_CredentialFields.ORD_ID],
                global_tenant_id=(
                    dep.get(_CredentialFields.GLOBAL_TENANT_ID)
                    or dep[_CredentialFields.DATA][_CredentialFields.GLOBAL_TENANT_ID]
                ),
            )
            for dep in data[_CredentialFields.INTEGRATION_DEPENDENCIES]
        ]
        logger.debug(
            "Loaded %d integration dependencies from credentials",
            len(integration_deps),
        )
    except (KeyError, TypeError) as e:
        raise AgentGatewaySDKError(
            f"Failed to parse integrationDependencies: {e}. "
            'Expected format: [{"ordId": "...", "globalTenantId": "..."}]'
        )

    return CustomerCredentials(
        token_service_url=data[_CredentialFields.TOKEN_SERVICE_URL],
        client_id=data[_CredentialFields.CLIENT_ID],
        certificate=data[_CredentialFields.CERTIFICATE],
        private_key=data[_CredentialFields.PRIVATE_KEY],
        gateway_url=data[_CredentialFields.GATEWAY_URL].rstrip("/"),
        integration_dependencies=integration_deps,
    )


def _create_ssl_context(certificate: str, private_key: str) -> ssl.SSLContext:
    """Create SSL context for mTLS from in-memory certificate and key.

    Uses temporary files as a bridge since ssl.SSLContext requires file paths
    or loaded certificate objects. The files are created with secure permissions
    and cleaned up immediately after loading.

    Note: While httpx supports passing cert as a tuple of file paths, it doesn't
    directly support in-memory certificates. Using temporary files is the most
    compatible approach across different SSL backends.

    Args:
        certificate: PEM-encoded certificate string.
        private_key: PEM-encoded private key string.

    Returns:
        Configured SSL context for mTLS.

    Raises:
        AgentGatewaySDKError: If SSL context creation fails.
    """
    cert_file = None
    key_file = None

    try:
        # Create temporary files with secure permissions (readable only by owner)
        cert_file = tempfile.NamedTemporaryFile(mode="w", suffix=".crt", delete=False)
        key_file = tempfile.NamedTemporaryFile(mode="w", suffix=".key", delete=False)

        cert_file.write(certificate)
        cert_file.close()
        key_file.write(private_key)
        key_file.close()

        # Create SSL context and load the certificate/key
        ssl_context = ssl.create_default_context()
        ssl_context.load_cert_chain(cert_file.name, key_file.name)

        return ssl_context

    except ssl.SSLError as e:
        raise AgentGatewaySDKError(f"Failed to create SSL context: {e}")

    finally:
        # Clean up temporary files
        if cert_file and os.path.exists(cert_file.name):
            os.unlink(cert_file.name)
        if key_file and os.path.exists(key_file.name):
            os.unlink(key_file.name)


def _request_token_mtls(
    credentials: CustomerCredentials,
    grant_type: str,
    timeout: float,
    extra_data: dict | None = None,
) -> dict:
    """Make mTLS token request to IAS.

    Args:
        credentials: Customer credentials with certificate and private key.
        grant_type: OAuth2 grant type.
        timeout: HTTP timeout in seconds.
        extra_data: Additional form data for the token request.

    Returns:
        Token response payload.

    Raises:
        AgentGatewaySDKError: If token request fails.
    """
    ssl_context = _create_ssl_context(credentials.certificate, credentials.private_key)

    data = {
        "client_id": credentials.client_id,
        "grant_type": grant_type,
        "resource": _AGW_RESOURCE_URN,
    }

    if extra_data:
        data.update(extra_data)

    logger.debug(
        "Requesting token from %s with grant_type=%s",
        credentials.token_service_url,
        grant_type,
    )

    try:
        with httpx.Client(
            verify=ssl_context,
            timeout=timeout,
        ) as client:
            response = client.post(
                credentials.token_service_url,
                data=data,
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Accept": "application/json",
                },
            )

        if response.status_code != 200:
            logger.error(
                "Token request failed with status %d: %s",
                response.status_code,
                response.text[:500],
            )
            raise AgentGatewaySDKError(
                f"Token request failed with status {response.status_code}: {response.text[:200]}"
            )

        token_data = response.json()
        access_token = token_data.get("access_token")

        if not access_token:
            raise AgentGatewaySDKError(
                f"Token response missing 'access_token'. Keys: {list(token_data.keys())}"
            )

        logger.debug("Token acquired successfully (length: %d)", len(access_token))
        return token_data

    except httpx.RequestError as e:
        raise AgentGatewaySDKError(f"Token request failed: {e}")


def get_system_token_mtls(
    credentials: CustomerCredentials,
    timeout: float,
    app_tid: str | None = None,
    token_cache: _TokenCache | None = None,
) -> str:
    """Get system-scoped token using mTLS client credentials flow.

    Used for tool discovery where user identity is not needed.

    Args:
        credentials: Customer credentials.
        timeout: HTTP timeout in seconds.
        app_tid: BTP Application Tenant ID of subscriber (optional).
        token_cache: Optional token cache used to reuse still-valid tokens.

    Returns:
        System-scoped access token, fetched or served from cache.
    """
    scope_key = _cache_scope_key(credentials, app_tid)
    if token_cache:
        cached_token = token_cache.get_system_token(scope_key)
        if cached_token:
            logger.debug("Using cached system token for scope '%s'", scope_key)
            return cached_token

    logger.info("Acquiring system token via mTLS client credentials")
    token_data = _request_token_mtls(
        credentials,
        grant_type=_GRANT_TYPE_CLIENT_CREDENTIALS,
        timeout=timeout,
        extra_data={"response_type": "token"},
    )
    access_token = token_data["access_token"]

    if token_cache:
        token_cache.set_system_token(
            access_token,
            token_cache.compute_expires_at(token_data),
            scope_key,
        )

    return access_token


def exchange_user_token(
    credentials: CustomerCredentials,
    user_token: str,
    timeout: float,
    app_tid: str | None = None,
    token_cache: _TokenCache | None = None,
) -> str:
    """Exchange user token for AGW-scoped token using jwt-bearer grant.

    Used for tool invocation where user identity must be preserved
    for principal propagation.

    Args:
        credentials: Customer credentials.
        user_token: User's JWT token to exchange.
        timeout: HTTP timeout in seconds.
        app_tid: BTP Application Tenant ID of subscriber (optional).
        token_cache: Optional token cache used to reuse still-valid exchanged
            tokens.

    Returns:
        AGW-scoped access token with user identity, fetched or served from cache.
    """
    scope_key = _cache_scope_key(credentials, app_tid)
    if token_cache:
        cached_token = token_cache.get_user_token(user_token, scope_key)
        if cached_token:
            logger.debug("Using cached exchanged user token for scope '%s'", scope_key)
            return cached_token

    logger.info("Exchanging user token for AGW-scoped token via jwt-bearer grant")
    extra: dict = {
        "assertion": user_token,
        "token_format": "jwt",
    }
    if app_tid:
        extra["app_tid"] = app_tid
    token_data = _request_token_mtls(
        credentials,
        grant_type=_GRANT_TYPE_JWT_BEARER,
        timeout=timeout,
        extra_data=extra,
    )
    access_token = token_data["access_token"]

    if token_cache:
        token_cache.set_user_token(
            user_token,
            access_token,
            token_cache.compute_expires_at(token_data),
            scope_key,
        )

    return access_token


def _build_mcp_url(gateway_url: str, ord_id: str, gt_id: str) -> str:
    """Build MCP server URL from gateway URL, ord_id, and gt_id.

    URL format: {gateway_url}/v1/mcp/{ord_id}/{gt_id}

    If gateway_url already contains /v1/mcp, it is preserved.

    Args:
        gateway_url: Base gateway URL from credentials.
        ord_id: Open Resource Discovery ID of the MCP server.
        gt_id: Global Tenant ID (looked up from integrationDependencies).

    Returns:
        Full MCP server URL.
    """
    # Gateway URL may or may not include /v1/mcp
    if "/v1/mcp" in gateway_url:
        return f"{gateway_url}/{ord_id}/{gt_id}"
    else:
        return f"{gateway_url}/v1/mcp/{ord_id}/{gt_id}"


async def _list_server_tools(
    url: str,
    auth_token: str,
    dependency: IntegrationDependency,
    timeout: float,
) -> list[MCPTool]:
    """List tools from a single MCP server.

    Args:
        url: MCP server endpoint URL.
        auth_token: Authorization token.
        dependency: Integration dependency (for metadata).

    Returns:
        List of MCPTool objects from this server.

    Raises:
        AgentGatewaySDKError: If server does not provide serverInfo.name.
    """
    async with httpx.AsyncClient(
        headers={
            "Authorization": f"Bearer {auth_token}",
            "x-correlation-id": str(uuid.uuid4()),
        },
        timeout=timeout,
    ) as http_client:
        async with streamable_http_client(url, http_client=http_client) as (
            read,
            write,
            _,
        ):
            async with ClientSession(read, write) as session:
                init_result = await session.initialize()

                if not (
                    init_result
                    and init_result.serverInfo
                    and init_result.serverInfo.name
                ):
                    raise AgentGatewaySDKError(
                        f"MCP server at '{url}' did not provide serverInfo.name. "
                        "This is required by the MCP protocol."
                    )

                server_name = init_result.serverInfo.name
                result = await session.list_tools()

                return [
                    MCPTool(
                        name=t.name,
                        server_name=server_name,
                        description=t.description or "",
                        input_schema=t.inputSchema or {},
                        url=url,
                    )
                    for t in result.tools
                ]


def _resolve_dependency(
    credentials: CustomerCredentials,
    ord_id: str,
) -> IntegrationDependency:
    """Resolve a single IntegrationDependency by ORD ID.

    Args:
        credentials: Customer credentials with integrationDependencies.
        ord_id: ORD ID to look up.

    Returns:
        The matching IntegrationDependency.

    Raises:
        AgentGatewaySDKError: If no match is found or multiple entries share the same ORD ID.
    """
    matches = [d for d in credentials.integration_dependencies if d.ord_id == ord_id]
    if not matches:
        available = ", ".join(d.ord_id for d in credentials.integration_dependencies)
        raise AgentGatewaySDKError(
            f"ORD ID '{ord_id}' not found in integrationDependencies. "
            f"Available: {available or '(none)'}"
        )
    if len(matches) > 1:
        tids = ", ".join(m.global_tenant_id for m in matches)
        raise AgentGatewaySDKError(
            f"ORD ID '{ord_id}' matches multiple integrationDependencies with "
            f"different tenant IDs ({tids}). Specify the tenant ID explicitly."
        )
    return matches[0]


async def get_mcp_tools_customer(
    credentials: CustomerCredentials,
    system_token: str,
    timeout: float,
    ord_id: str | None = None,
) -> list[MCPTool]:
    """List MCP tools from servers defined in credentials.

    When ord_id is given, only tools from that single dependency are returned
    and the tenant ID is derived automatically from the credentials.
    When ord_id is omitted, tools from all integrationDependencies are returned.

    Args:
        credentials: Customer credentials with integrationDependencies.
        system_token: Pre-fetched raw system token for authentication.
        timeout: HTTP timeout in seconds for MCP server calls.
        ord_id: Optional ORD ID to filter to a single server. The tenant ID
            is derived from the credentials — no need to pass it separately.
            Raises AgentGatewaySDKError if the ORD ID matches multiple entries.

    Returns:
        List of MCPTool objects from the matching server(s).

    Raises:
        AgentGatewaySDKError: If integrationDependencies is empty, or if ord_id
            is given but not found or matches multiple tenant IDs.
    """
    dependencies = credentials.integration_dependencies

    if not dependencies:
        raise AgentGatewaySDKError(
            "integrationDependencies is empty in credentials — no MCP servers configured."
        )

    if ord_id is not None:
        dependencies = [_resolve_dependency(credentials, ord_id)]

    logger.info("Discovering tools from %d MCP server(s)", len(dependencies))

    tools: list[MCPTool] = []

    for dep in dependencies:
        url = _build_mcp_url(credentials.gateway_url, dep.ord_id, dep.global_tenant_id)
        logger.debug(
            "Discovering tools from %s (ord_id=%s, gt_id=%s)",
            url,
            dep.ord_id,
            dep.global_tenant_id,
        )

        try:
            server_tools = await _list_server_tools(url, system_token, dep, timeout)
            tools.extend(server_tools)
            logger.debug("Loaded %d tool(s) from %s", len(server_tools), dep.ord_id)
        except Exception:
            logger.exception("Failed to load tools from %s — skipping", dep.ord_id)

    logger.info(
        "Loaded %d MCP tool(s) from %d server(s)", len(tools), len(dependencies)
    )
    return tools
